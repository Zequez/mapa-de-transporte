$(function(){$(".datepicker").b({a:"yy-mm-dd"});return $(".clear_filters_btn").click(function(){window.location.search="";return!1})});
